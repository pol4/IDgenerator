﻿All notable changes to this project will be documented in this file.

The format is based on Keep a Changelog

## [0.2.1] - 2022-07-11
### Added
  - IDmodule now has docstrings and comments
  - Test for IDGen
### Changed
  - CHANGELOG.md
  - LICENSE.md
  - README.md

## [0.1.1] - 2022-07-08
### Added
  - .gitignore
  - CHANGELOG.md
  - LICENSE.md
  - README.md
  - requirements.txt
  
## [0.1.0] - 2022-07-07
### Added
  - IDmodule.py
  
